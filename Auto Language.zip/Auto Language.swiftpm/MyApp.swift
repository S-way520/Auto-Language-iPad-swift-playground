import SwiftUI
@main
struct MyApp: App {
    @State var language: String = LanguageManager.shared.getAppLanguage()
    var body: some Scene {
        WindowGroup {
            ZStack{
                ContentView()
                    .onReceive(NotificationCenter.default.publisher(for: NSLocale.currentLocaleDidChangeNotification)) { _ in
                        let newLanguage = LanguageManager.shared.getAppLanguage()
                        if newLanguage != language {
                            language = newLanguage
                        }
                    }
                    .environment(\.locale, .init(identifier: language)) 
            }
        }
    }
}
class LanguageManager {
    // MARK: - Properties
    static let shared = LanguageManager()
    private let defaults = UserDefaults.standard
    // MARK: - Public Methods
    func setAppLanguage(to language: String) {
        defaults.set([language], forKey: "AppleLanguages")
        defaults.synchronize()
    }
    func getAppLanguage() -> String {
        guard let languages = defaults.object(forKey: "AppleLanguages") as? [String],
              let language = languages.first else {
            return "en"
        }
        return language
    }
}
