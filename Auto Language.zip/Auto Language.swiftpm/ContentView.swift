import SwiftUI
struct ContentView: View {
    @Environment(\.locale) var locale
    var languageCode: String? {locale.language.languageCode?.identifier}
    var isChineseLanguage: Bool { languageCode == "zh"}
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            if isChineseLanguage {
                Text("你好，世界！")
            } else {
                Text("Hello, world!")
            }
        }
    }
}
